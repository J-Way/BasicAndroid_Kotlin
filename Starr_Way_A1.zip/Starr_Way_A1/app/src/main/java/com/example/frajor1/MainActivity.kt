package com.example.frajor1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /////// list for peeps spinner
        val peeps=findViewById<Spinner>(R.id.peepSpinner)
        val peepAmt = arrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
        peeps.adapter=ArrayAdapter<Int>(this, android.R.layout.simple_list_item_1,peepAmt)
        ////////

        ////list for tip type spinner
        val tipType=findViewById<Spinner>(R.id.tipTypeSpinner)
        val tipAmt =arrayOf("10", "15", "20", "other %", "other $")
        tipType.adapter=ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,tipAmt)
        ////

        //////clear button functionality
        val tipResult=findViewById<TextView>(R.id.tipResult)
        val totalResult=findViewById<TextView>(R.id.totalResult)
        val perResult=findViewById<TextView>(R.id.perResult)
        val perStarter=findViewById<TextView>(R.id.perStarter)
        val amount=findViewById<EditText>(R.id.amountInput)
        val tip=findViewById<EditText>(R.id.tipInput)
        val cancel =findViewById<Button>(R.id.clearButton)
        cancel.setOnClickListener{
            tipResult.text=""
            totalResult.text=""
            perStarter.visibility = View.INVISIBLE
            perResult.text=""
            amount.text.clear()
            tip.text.clear()
            tipType.setSelection(0)
            peeps.setSelection(0)
        }
        //////

        ////functions
        fun isNumeric(input: String): Boolean =
            try {
                input.toDouble()
                true
            } catch(e: NumberFormatException) {
                false
            }
        fun totalVal(amount: Double,tip: Double): String{
            return "$"+"%.${2}f".format(amount*(1+tip/100.0))
        }
        fun tipVal(amount: Double,tip: Double): String{
            return "$"+"%.${2}f".format(amount*tip/100.0)
        }
        fun perVal(amount: Double,tip: Double, peeps: Int): String{
            return "$"+"%.${2}f".format(amount*(1+tip/100.0)/peeps)
        }
        ///
        ////calculate button functionality
        val calculate=findViewById<Button>(R.id.calcButton)
        calculate.setOnClickListener{
            if(amount.text.isEmpty()){
                val errorBox= AlertDialog.Builder(this)
                errorBox.setTitle("Error No Input")
                errorBox.setMessage("You need to put a value in the amount field")
                errorBox.show()

                amount.requestFocus()
            }
            else if(tip.text.isEmpty()&&!isNumeric(tipType.selectedItem.toString())){

                Toast.makeText(applicationContext, "Other% or Other$ must be entered", Toast.LENGTH_LONG).show()
            }
            else{
                var x:Double=-100.0
                when{
                    isNumeric(tipType.selectedItem.toString()) -> x=tipType.selectedItem.toString().toDouble()
                    tipType.selectedItem.toString().endsWith("%") -> x=tip.text.toString().toDouble()
                    tipType.selectedItem.toString().endsWith(("$")) -> x=tip.text.toString().toDouble()*100.0/amount.text.toString().toDouble()
                }

                totalResult.text=totalVal(amount.text.toString().toDouble(),x)
                tipResult.text=tipVal(amount.text.toString().toDouble(),x)
                if (peeps.selectedItem.toString().toInt()>1) {
                    perStarter.text = resources.getString(R.string.GroupTotal)
                    perResult.text=perVal(amount.text.toString().toDouble(),x,peeps.selectedItem.toString().toInt())
                }
                else
                {
                    perStarter.text = ""
                    perResult.text = ""
                }
            }
        }
        /////
        ////focus on tip if tipType is other
        tipType.onItemSelectedListener=object:
            AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (!isNumeric(tipType.selectedItem.toString())){
                    tip.isEnabled=true
                    tip.requestFocus()
                    tip.hint="enter"
                }
                else {
                    tip.isEnabled=false
                    tip.hint=""
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.about_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //return super.onOptionsItemSelected(item)
        return when (item.itemId) {
            R.id.aboutItem ->{
                val aboutBox= AlertDialog.Builder(this)
                aboutBox.setTitle("About This Application")
                aboutBox.setMessage("Francis Starr and Jordan Way team up to build this great tip calculator" +
                        "\n 1. Put a value in the Amount field" +
                        "\n 2. Determine how much you want to tip (% or $ amount)" +
                        "\n 3. Fill out the number of people who are paying the bill" +
                        "\n 4. Hit calculate to see your results")
                aboutBox.show()
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
}
}
