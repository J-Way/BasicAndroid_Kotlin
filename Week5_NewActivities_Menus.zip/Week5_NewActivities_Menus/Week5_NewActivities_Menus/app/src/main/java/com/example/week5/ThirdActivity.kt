package com.example.week5

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_third.*


class ThirdActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val button1 = findViewById<Button>(R.id.button1);

        button1.setOnClickListener {

            val returnIntent = Intent()
            returnIntent.putExtra("result", "RESULT")
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }

        val button2 = findViewById<Button>(R.id.button2);

        button2.setOnClickListener {

            //If you don't want to return data:
             val returnIntent = Intent()
             setResult(Activity.RESULT_CANCELED, returnIntent)
             finish()
        }




    }
}
