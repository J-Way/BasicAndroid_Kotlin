package com.example.week5

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private val LAUNCH_SECOND_ACTIVITY = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.secondActivityButton);

        button.setOnClickListener {
            val intent = Intent(this@MainActivity, SecondActivity::class.java)

            // To pass any data to next activity
            intent.putExtra("NAME", "Yash")

            // start your next activity
            startActivity(intent)
        }


        val button2 = findViewById<Button>(R.id.thirdActivityButton);

        button2.setOnClickListener {

            val intent:Intent = Intent(this@MainActivity, ThirdActivity::class.java);
            startActivityForResult(intent, LAUNCH_SECOND_ACTIVITY);
        }



    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {

        val resultTV = findViewById(R.id.resultTextView) as TextView;

        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                val result = data?.getStringExtra("result")
                resultTV.text = result
            }
            if (resultCode == Activity.RESULT_CANCELED) { //Write your code if there's no result
                resultTV.text = "You Little piece of @#!*"
            }
        }
    } //onActivityResult



}
