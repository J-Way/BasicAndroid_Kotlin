package com.example.week5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val txtView = findViewById(R.id.textView) as TextView;


       var bundle :Bundle ?=intent.extras
        var message = bundle!!.getString("NAME") // 1
        var name: String = intent.getStringExtra("NAME") // 2

        txtView.text = name;



    }
}
