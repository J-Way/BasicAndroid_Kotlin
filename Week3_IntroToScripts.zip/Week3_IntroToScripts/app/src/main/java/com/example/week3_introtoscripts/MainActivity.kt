package com.example.week3_introtoscripts

import android.nfc.Tag
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val TAG = "MAIN_ACTIVITY"

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val BMICalculator = findViewById(R.id.submit) as Button
        val heightFT = findViewById(R.id.HeightFeetPrompt) as EditText
        val heightIn= findViewById(R.id.HeightInchInput) as EditText
        val weight= findViewById(R.id.weight) as EditText
        val result= findViewById(R.id.output) as TextView
        val unitType = findViewById(R.id.Units) as Switch

        unitType.setOnClickListener{
            if(unitType.isEnabled){
                unitType.text = "Metric"
                Log.i(TAG, "using metric")
            }
            else{
                unitType.text = "Imperial"
                Log.i(TAG, "using imperial")
            }
        }

        BMICalculator.setOnClickListener {

            if(!unitType.isEnabled) {
                val a = heightFT.text.toString().toInt() * 12 + heightIn.text.toString().toInt()
                Log.i(TAG, "a = " + a)
                result.text = (703 * (weight.text.toString().toInt() / Math.pow(
                    a.toDouble(),
                    2.toDouble()
                ))).toString()
            }
            else{
                val a = heightFT.text.toString().toInt() * 100 + heightIn.text.toString().toInt()
                Log.i(TAG, "a = " + a)

                result.text = (weight.text.toString().toInt() / Math.pow(a.toDouble(), 2.toDouble())).toString()
            }

            val myToast = Toast.makeText(getApplicationContext(),"calculon", Toast.LENGTH_SHORT)

            myToast.show()
        }
    }
}
