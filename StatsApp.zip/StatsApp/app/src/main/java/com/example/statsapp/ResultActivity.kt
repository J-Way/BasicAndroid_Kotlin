package com.example.statsapp

import android.os.Bundle
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_result.*

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        setSupportActionBar(toolbar)

        val txtView = findViewById(R.id.resultTextView) as TextView;


        var bundle :Bundle ?=intent.extras
        var message = bundle!!.getString("RESUlT") // 1
        var name: String = intent.getStringExtra("RESULT") // 2

        txtView.text = name;
    }

}
