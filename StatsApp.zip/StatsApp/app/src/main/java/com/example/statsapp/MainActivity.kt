package com.example.statsapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var numbers:ArrayList<Double> = ArrayList<Double>()
private var choice: String = "";
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val languages = resources.getStringArray(R.array.Choices)

        // access the spinner
        val spinner = findViewById<Spinner>(R.id.choiceSpinner)
        if (spinner != null) {
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item, languages
            )
            spinner.adapter = adapter


            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                    if(parent.getItemAtPosition(position).toString().equals("Count")){
                        choice = "COUNT"
                    }
                    if(parent.getItemAtPosition(position).toString().equals("Min")){
                    choice = "MIN"
                    }
                    if(parent.getItemAtPosition(position).toString().equals("Max")){
                    choice = "MAX"
                    }
                    if(parent.getItemAtPosition(position).toString().equals("Sort")){
                        choice = "SORT"
                    }
                    if(parent.getItemAtPosition(position).toString().equals("Mean")){
                        choice = "MEAN"
                    }


                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    choice = ""
                }

            }
        }
        val button = findViewById<Button>(R.id.AddSetButton)


        button.setOnClickListener {
            val editText = findViewById(R.id.numberEditText) as EditText
            numbers.add(editText.text.toString().toDouble())
            Toast.makeText(applicationContext, "Number successfully added to set", Toast.LENGTH_LONG)
        }


        ComputeButton()
    }


    fun ComputeButton(){
        val button = findViewById<Button>(R.id.Computebutton);

        button.setOnClickListener {
            var result:Double  = 0.0

            if(choice == "COUNT")
            result = Count().toDouble()

            //send response
            val intent = Intent(this@MainActivity, ResultActivity::class.java)

            // To pass any data to next activity
            intent.putExtra("RESULT", result.toString())

            // start your next activity
            startActivity(intent)
        }
    }

    fun Mean(): Double {

        var sum = 0.0;
        numbers.forEach{
            sum = sum + it
        }
        return sum / numbers.count()
    }

    fun Min(): Double {

        var min = numbers[0]
        numbers.forEach{
            if (it < min)
                min = it
        }
        return min
    }


        fun Max(): Double {

            var max = numbers[0]
            numbers.forEach{
                if (it > max)
                    max = it
            }
            return max
        }

    fun Count(): Int {

            return numbers.count()
        }

    fun Sort(): List<Double> {

        val sortedValues = mutableListOf(numbers)
        return numbers.sortedByDescending { it.toDouble() }

    }
}
