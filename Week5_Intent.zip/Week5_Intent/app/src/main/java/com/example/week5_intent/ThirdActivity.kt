package com.example.week5_intent

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_third.*

class ThirdActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        val textView = findViewById<TextView>(R.id.textResult)

        val bundle: Bundle ?=intent.extras
        val message = bundle!!.getString("NAME") //option 1
        val strUser: String = intent.getStringExtra(("NAME")) //option 2

        textView.text = "HI " + strUser
    }

}
