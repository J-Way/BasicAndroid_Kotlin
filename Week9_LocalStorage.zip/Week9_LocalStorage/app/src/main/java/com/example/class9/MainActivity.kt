package com.example.class9

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.os.Environment
import java.io.*
import java.lang.StringBuilder

class MainActivity : AppCompatActivity() {
    private val filepath = "MyFileStorage"
    internal var myExternalFile: File?=null

    private val isExternalStorageReadOnly: Boolean get() {
        val extStrorageState = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStrorageState)
    }

    private val isExternalStorageAvailable: Boolean get() {
        val extStorageState = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED.equals(extStorageState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //CODE HERE
        val fileName = findViewById<EditText>(R.id.editTextFile)
        val fileData = findViewById<EditText>(R.id.editTextData)

        val saveButton = findViewById<Button>(R.id.button_save)
        val viewButton = findViewById<Button>(R.id.button_view)

        saveButton.setOnClickListener(View.OnClickListener
            {
                myExternalFile = File(getExternalFilesDir(filepath),
                fileName.text.toString())

                try{
                    val fileOutputStream = FileOutputStream(myExternalFile)
                    fileOutputStream.write(fileData.text.toString().toByteArray())
                    fileOutputStream.close()
                }
                catch (e: IOException){
                    e.printStackTrace()
                }

                Toast.makeText(applicationContext, "data save",
                    Toast.LENGTH_SHORT).show()
            }
        )

        viewButton.setOnClickListener(View.OnClickListener {
                myExternalFile = File(getExternalFilesDir(filepath),
                    fileName.text.toString())

                val fileNameString = fileName.text.toString()
                myExternalFile = File(getExternalFilesDir(filepath), fileNameString)

                if(fileNameString.toString() != null && fileNameString.toString().trim() != ""){
                    var fileInputStream = FileInputStream(myExternalFile)

                    var inputStreamReader: InputStreamReader = InputStreamReader(fileInputStream)

                    val bufferedReader: BufferedReader = BufferedReader((inputStreamReader))

                    val stringBuilder: StringBuilder = StringBuilder()
                    var text: String? = null

                    while({text = bufferedReader.readLine(); text} () != null){
                        stringBuilder.append(text)
                    }
                    fileInputStream.close()

                    Toast.makeText(applicationContext,
                        stringBuilder.toString(), Toast.LENGTH_SHORT).show()

                    if(!isExternalStorageAvailable || isExternalStorageReadOnly)
                        saveButton.isEnabled = false
                }
            }
        )
   }
}
