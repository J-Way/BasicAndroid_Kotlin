package com.example.nhlinfo_jordanway

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.exercise3_nhlinfo_jordanway.Team
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject


class MainActivity : AppCompatActivity() {
    private var listView: ListView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btnDisplay = findViewById<Button>(R.id.btnGetInfo)
        listView = findViewById<ListView>(R.id.lstDisplay)

        btnDisplay.setOnClickListener {
            getPlayers()
        }
    }

    // function for network call
    fun getPlayers() {
    // Instantiate the RequestQueue.
    val queue = Volley.newRequestQueue(this)
    val url: String = "https://statsapi.web.nhl.com/api/v1/teams"
    var curTeam :Team = Team()
    var teams :ArrayList<Team> = ArrayList<Team>()
    // Request a string response from the provided URL.
    val stringReq = StringRequest(Request.Method.GET, url,
            Response.Listener<String> { response ->

                var strResp = response.toString()
                val jsonObj: JSONObject = JSONObject(strResp)
                val jsonArray: JSONArray = jsonObj.getJSONArray("teams")
                //var str_user: String = ""
                for (i in 0 until jsonArray.length()) {
                    var jsonInner: JSONObject = jsonArray.getJSONObject(i)
                    curTeam = Team(jsonInner.get("name").toString(), jsonInner.getJSONObject("venue").get("city").toString(), jsonInner.get("firstYearOfPlay").toString())
                    teams.add(curTeam)
                }
                populateList(teams)
            },
            Response.ErrorListener { btnGetInfo!!.text = "That didn't work!" })
            queue.add(stringReq)
    }

    fun populateList(team: ArrayList<Team>){
        val listItems = arrayOfNulls<String>(team.size)

        for (i in 0 until team.size) {
            val team = team[i]
            listItems[i] = team.teamName
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems)
        listView?.adapter  = adapter
    }
}
