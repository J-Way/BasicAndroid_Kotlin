package com.example.exercise3_nhlinfo_jordanway

class Team{
    var teamName: String = ""
    var locationName: String = ""
    var firstPlayYear: String =""

    constructor(tName: String, locName: String, playYear: String){
        this.teamName = tName
        this.locationName = locName
        this.firstPlayYear = playYear
    }

    constructor(){

    }
}