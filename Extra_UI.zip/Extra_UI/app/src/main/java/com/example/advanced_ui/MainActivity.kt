package com.example.advanced_ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Debug
import android.service.autofill.OnClickAction
import android.util.Log
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.view.*
import java.nio.file.attribute.GroupPrincipal

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val p = findViewById(R.id.PrincipalEditText) as EditText
        val r = findViewById(R.id.RateEditText) as EditText
        val n = findViewById<EditText>(R.id.TermsEditText) as EditText

        val submit = findViewById(R.id.SubmitButton) as Button
        val result = findViewById(R.id.CompoundedSpinner) as Spinner
        val compounded = findViewById(R.id.checkBox) as CheckBox

        val termOptions =
            arrayOf("Weekly", "Bi-weekly", "Monthly", "Yearly")

        submit.setOnClickListener() {
            if(compounded.isChecked == false) {
                val x = SimpleInterest(
                    p.text.toString().toDouble(),
                    n.text.toString().toDouble(),
                    r.text.toString().toDouble()
                )

                Toast.makeText(applicationContext, x.toString(), Toast.LENGTH_SHORT).show()
            }
            else{
                val x = compoundInterest(
                    p.text.toString().toDouble(),
                    n.text.toString().toDouble(),
                    r.text.toString().toDouble()
                )

                Toast.makeText(applicationContext, x.toString(), Toast.LENGTH_SHORT).show()
            }
        }
    }
    //simple interest
    fun SimpleInterest(p:Double, r:Double, n:Double) :Double{
        val res = (p * n * r) / 100.0
        return res
    }

    //compound
    fun compoundInterest(principal:Double, rate:Double, terms:Double) : Double{
        val res = principal*Math.pow((1+(rate/100)/terms), terms)
        return res
    }
}