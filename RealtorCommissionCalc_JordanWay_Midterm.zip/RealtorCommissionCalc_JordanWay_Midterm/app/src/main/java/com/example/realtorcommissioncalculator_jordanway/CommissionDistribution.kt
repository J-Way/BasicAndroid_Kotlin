package com.example.realtorcommissioncalculator_jordanway

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class CommissionDistribution : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_commission_distribution)

        val txtHousePrice = findViewById<TextView>(R.id.txtHousePrice)
        val txtAllComm = findViewById<TextView>(R.id.txtAllComm)
        val txtBuy = findViewById<TextView>(R.id.txtBuyAgent)
        val txtListA = findViewById<TextView>(R.id.txtSellAgent)
        val txtListB = findViewById<TextView>(R.id.txtSellBroke)

        /*
                // To pass any data to next activity
        intent.putExtra("allComm", grandTotal.toString())
        intent.putExtra("listAgent", lsAgent)
        intent.putExtra("buyAgent", bAgent)

         */

        var housePrice: String = intent.getStringExtra("homeVal")
        var allComm: String = intent.getStringExtra("allComm")
        var buyA: String = intent.getStringExtra("buyAgent")
        var listA: String = intent.getStringExtra("listAgent")
        var listB: String = intent.getStringExtra("listBroker")

        txtHousePrice.text = "Total House Price = " + housePrice
        txtAllComm.text = "Total Commission " +  allComm
        txtBuy.text = "Buyer Agent Comm " + buyA
        txtListA.text = "List Agent Comm " + listA
        txtListB.text = "List Broker Comm " + listB
    }
}
