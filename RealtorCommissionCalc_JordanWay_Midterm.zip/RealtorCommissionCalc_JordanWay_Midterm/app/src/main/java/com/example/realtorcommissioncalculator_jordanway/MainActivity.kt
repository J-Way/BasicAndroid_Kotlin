package com.example.realtorcommissioncalculator_jordanway

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import android.view.View

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val homeVal = findViewById<EditText>(R.id.numHomeValue)
        val commission = findViewById<EditText>(R.id.numCommission)

        val listAgent = findViewById<CheckBox>(R.id.chkListAgent)
        val listBroker = findViewById<CheckBox>(R.id.chkListBroker)
        val buyAgent = findViewById<CheckBox>(R.id.chkBuyAgent)
        val buyAgentBroker = findViewById<CheckBox>(R.id.chkBuyAgentBroker)

        val commAmt =arrayOf("70-30%", "50-50%", "60-40%")
        val commPercent = findViewById<Spinner>(R.id.spnCommPercent)
        commPercent.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,commAmt)
        commPercent.isEnabled = false

        val btnCalc = findViewById<Button>(R.id.btnCalc)


        var split = 0.0
        commPercent.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {

                if (parent.getItemAtPosition(position).toString().equals("70-30%")) {
                    split = 70.0 / 100
                }
                if (parent.getItemAtPosition(position).toString().equals("50-50%")) {
                    split = 50.0 / 100
                }
                if (parent.getItemAtPosition(position).toString().equals("60-40%")) {
                    split = 60.0 / 100
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                split = 0.0
            }
        }


        fun showSpinner(){
            commPercent.isEnabled = false

            // if all false
            if(listAgent.isChecked || listBroker.isChecked || buyAgent.isChecked || buyAgentBroker.isChecked)
                commPercent.isEnabled = true
        }

        fun invalidSelection() {
            Toast.makeText(
                applicationContext,
                "Every deal must have a Listing Agent and Buyers Agent",
                Toast.LENGTH_LONG
            ).show()
        }

        btnCalc.setOnClickListener{
            if(!listAgent.isChecked || !buyAgent.isChecked)
                invalidSelection()
            else
                commissionCalculator(split, homeVal.text.toString().toDouble())
        }

        listAgent.setOnClickListener{
            showSpinner()
        }
        listBroker.setOnClickListener{
            showSpinner()
        }
        buyAgent.setOnClickListener{
            showSpinner()
        }
        buyAgentBroker.setOnClickListener{
            showSpinner()
        }

    }

    // Split is
    private  fun commissionCalculator(split:Double,homeVal:Double ) {
        var fees = homeVal * (numCommission.text.toString().toDouble() / 100) / 2

        var lsAgent = fees
        var lsBroke = fees
        var bAgent = fees
        var bBroke = fees

        lsAgent *= split
        lsBroke *= (100 - split * 100) / 100.0

        bAgent *= split
        bBroke *= (100 - split * 100) / 100.0

        var brokerTax = bBroke + calculateTax(bBroke)
        var agentTax = lsAgent + calculateTax(lsAgent)

        var grandTotal = brokerTax * 2  +agentTax * 2


        //send response
        val intent = Intent(this@MainActivity, CommissionDistribution::class.java)

        intent.putExtra("allComm", Math.ceil(grandTotal).toString())
        intent.putExtra("homeVal", homeVal.toString())
        intent.putExtra("listAgent", Math.ceil(lsAgent).toString())
        intent.putExtra("buyAgent", Math.ceil(bAgent).toString())
        intent.putExtra("listBroker", Math.ceil(lsBroke).toString())

        startActivity(intent)
    }

    private fun calculateTax(preTax: Double): Double {
        var afterTax = preTax * 0.13
        return afterTax
    }
}
