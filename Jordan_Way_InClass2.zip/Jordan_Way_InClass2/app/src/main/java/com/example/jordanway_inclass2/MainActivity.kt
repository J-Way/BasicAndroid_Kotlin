package com.example.jordanway_inclass2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Intent
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var txtEvalTitle: EditText
    lateinit var txtGrade: EditText
    lateinit var txtOutOf: EditText
    lateinit var txtWeight: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedPrefs = SharedPrefs(this)
        var counter = 1;

        txtEvalTitle = findViewById(R.id.txtEvalTitle)
        txtGrade = findViewById(R.id.txtGrade)
        txtOutOf = findViewById(R.id.txtOutOf)
        txtWeight = findViewById(R.id.txtWeight)

        sharedPrefs.saveString("first_name", "jordan")
        sharedPrefs.saveString("last_name", "way")
        sharedPrefs.saveString("assign_1", "65")
        sharedPrefs.saveString("assign_2", "88")
        sharedPrefs.saveString("assign_3", "55")
        sharedPrefs.saveString("midterm", "100")
        sharedPrefs.saveString("final", "54")

        btnSave.setOnClickListener{
            if(txtEvalTitle.text.isEmpty()){
               Toast.makeText(
                    applicationContext,
                    "Every Evaluation needs a title",
                    Toast.LENGTH_LONG
                ).show()
            }
            else if(txtGrade.text.isEmpty()){
                Toast.makeText(
                    applicationContext,
                    "Every Evaluation needs a grade",
                    Toast.LENGTH_LONG
                ).show()
            }
            else if(txtOutOf.text.isEmpty()){
                Toast.makeText(
                    applicationContext,
                    "Every Evaluation needs to be out of something",
                    Toast.LENGTH_LONG
                ).show()
            }
            else if(txtWeight.text.isEmpty()){
                Toast.makeText(
                    applicationContext,
                    "Every Evaluation needs a weighting",
                    Toast.LENGTH_LONG
                ).show()
            }
            else {
                val eval = txtEvalTitle.editableText.toString()
                val grade = txtGrade.text.toString().toInt()

                sharedPrefs.saveString("evalName" + counter, eval)
                sharedPrefs.saveString("grade" + counter, grade.toString())
                counter++
            }
        }

        btnView.setOnClickListener{
            //send response
            val intent = Intent(this@MainActivity, ViewGrade::class.java)

            intent.putExtra("count",counter.toString())

            startActivity(intent)
        }
    }
}
