package com.example.jordanway_inclass2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ViewGrade : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_grade)

        val count = intent.getStringExtra("count").toString().toInt()
        var i = 1;

        val txtOut = findViewById<TextView>(R.id.txtEvalOut)
        val txtGradeOut = findViewById<TextView>(R.id.txtGradeOut)
        val sharedPrefs = SharedPrefs(this)

        var eval = "First Name \t"  + "\n" +
               "Last Name \t"+ "\n" +
                "Assignment 1 \t"+ "\n" +
               "Assignment 2 \t" + "\n" +
                "Assignment 3 \t" + "\n" +
               "Midterm Exam \t" + "\n" +
               "Final Exam \t"

        var grade = sharedPrefs.getValueString("first_name") + "\n" +
         sharedPrefs.getValueString("last_name") + "\n" +
                sharedPrefs.getValueString("assign_1")+ "\n" +
                  sharedPrefs.getValueString("assign_2" )+ "\n" +
                 sharedPrefs.getValueString("assign_3" )+ "\n" +
                sharedPrefs.getValueString("midterm" )+ "\n" +
                sharedPrefs.getValueString("final" )
        while(i < count){
            eval += "\n" + sharedPrefs.getValueString("evalName" + i)
            grade += "\n" +  sharedPrefs.getValueString("grade"+i)
            i++
        }

        txtOut.text = eval
        txtGradeOut.text = grade
    }
}
